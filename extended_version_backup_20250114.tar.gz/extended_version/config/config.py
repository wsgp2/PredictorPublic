"""
Конфигурация API ключей.
Скопируйте этот файл в config.py и заполните своими ключами.
НЕ добавляйте config.py в git!
"""

# Blockchain.com API credentials
BLOCKCHAIN_API_KEY = "c38809f0-441c-4aca-b860-f09971cd0582"
BLOCKCHAIN_API_SECRET = "eyJhbGciOiJFUzI1NiIsInR5cCI6IkFQSSJ9.eyJpc3MiOiJibG9ja2NoYWluIiwiYXVkIjoibWVyY3VyeSIsImlhdCI6MTczNjEzODU0NiwianRpIjoiYzM4ODA5ZjAtNDQxYy00YWNhLWI4NjAtZjA5OTcxY2QwNTgyIiwidWlkIjoiOWY0OTlkYWMtMGRlZS00NzI1LThmYzMtMzliN2ZiOTFmMGQ1Iiwic2VxIjo4MjAzNTQ5LCJyZG8iOnRydWUsIndkbCI6ZmFsc2V9.H4bxFrE3aKa37ZTYbAX+BiPz6yDPDxxIoO3wxCVWfv/0JTEXwTedaHxLd+WH6mESX0xd6gFxQzSzWah9+JKyNP8="

LUNARCRUSH_API_KEY = 'czj05lqp91si9h16b975gtgbe2m5nblt367frwltf'

API_FRED = 'bb08bba3969b795cb832f4c1eb721494'

# Twitter API credentials (для анализа настроений)
TWITTER_API_KEY = "your_twitter_api_key"
TWITTER_API_SECRET = "your_twitter_api_secret"
TWITTER_BEARER_TOKEN = "your_twitter_bearer_token"

# Google Trends API не требует ключей

# News API credentials (для анализа новостей)
NEWS_API_KEY = "your_news_api_key"

# Database configuration
DB_CONFIG = {
    'dbname': 'bitcoin_prediction',
    'user': 'postgres',
    'password': '',  # Для локальной разработки можно оставить пустым
    'host': 'localhost',
    'port': '5432'
}  # <-- Здесь должна быть закрывающая фигурная скобка

# Настройки сбора данных
DATA_COLLECTION = {
    'historical_days': 365,  # Количество дней для исторических данных
    'update_interval': 3600  # Интервал обновления в секундах
}
