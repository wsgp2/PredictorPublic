import logging
from database.database_manager import DatabaseManager
import pandas as pd
from datetime import datetime

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class DB:
    def __init__(self):
        """Инициализация класса для работы с базой данных"""
        from database_manager import DatabaseManager
        self.db = DatabaseManager()
        logger.info("Successfully connected to the database")
        self.db.connect()
        logger.info("Database connection established")

    def __del__(self):
        """Закрытие соединения при удалении объекта"""
        if hasattr(self, 'db'):
            self.db.disconnect()
            logger.info("Database connection closed")

    def insert_price_data(self, df):
        """Вставка данных о ценах"""
        try:
            self.db.insert_price_data(df)
        except Exception as e:
            logger.error(f"Error inserting price data: {str(e)}")
            raise

    def insert_market_data(self, df):
        """Вставка рыночных данных"""
        try:
            self.db.insert_market_data(df)
        except Exception as e:
            logger.error(f"Error inserting market data: {str(e)}")
            raise

    def insert_longshort_data(self, df):
        """Вставка данных о Long/Short позициях"""
        try:
            self.db.insert_longshort_data(df)
        except Exception as e:
            logger.error(f"Error inserting long/short data: {str(e)}")
            raise

    def insert_technical_indicators(self, df):
        """Вставка технических индикаторов"""
        try:
            self.db.insert_technical_indicators(df)
        except Exception as e:
            logger.error(f"Error inserting technical indicators: {str(e)}")
            raise

    def insert_on_chain_metrics(self, df):
        """Вставка метрик блокчейна"""
        try:
            self.db.insert_on_chain_metrics(df)
        except Exception as e:
            logger.error(f"Error inserting on-chain metrics: {str(e)}")
            raise

    def insert_sentiment_metrics(self, df):
        """Вставка метрик настроений"""
        try:
            self.db.insert_sentiment_metrics(df)
        except Exception as e:
            logger.error(f"Error inserting sentiment metrics: {str(e)}")
            raise

    def insert_related_assets(self, df):
        """Вставка данных связанных активов"""
        try:
            self.db.insert_related_assets(df)
        except Exception as e:
            logger.error(f"Error inserting related assets: {str(e)}")
            raise

    def insert_news_data(self, df):
        """Вставка новостных данных"""
        try:
            self.db.insert_news_data(df)
        except Exception as e:
            logger.error(f"Error inserting news data: {str(e)}")
            raise

    def insert_trends_data(self, df: pd.DataFrame) -> None:
        """
        Вставка данных Google Trends в базу данных
        
        Args:
            df: DataFrame с данными трендов
        """
        try:
            # Создаем таблицу если её нет
            self.db.cursor.execute("""
                CREATE TABLE IF NOT EXISTS google_trends (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp DATETIME NOT NULL,
                    source TEXT NOT NULL,
                    category TEXT NOT NULL,
                    keyword TEXT NOT NULL,
                    value FLOAT NOT NULL,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(timestamp, category, keyword)
                )
            """)
            
            # Вставляем данные
            df.to_sql('google_trends', self.db.conn, if_exists='append', index=False)
            self.db.conn.commit()
            
        except Exception as e:
            self.db.conn.rollback()
            raise Exception(f"Error inserting trends data: {str(e)}")

    def get_latest_trends_dates(self) -> dict:
        """
        Получение последних дат для каждой категории Google Trends
        
        Returns:
            Словарь с последними датами по категориям
        """
        try:
            query = """
                SELECT category, MAX(timestamp) as last_date
                FROM google_trends
                GROUP BY category
            """
            
            df = pd.read_sql_query(query, self.db.conn)
            return dict(zip(df['category'], pd.to_datetime(df['last_date'])))
            
        except Exception as e:
            raise Exception(f"Error getting latest trends dates: {str(e)}")

    def get_trends_data(self, category: str = None, start_date: datetime = None, 
                       end_date: datetime = None) -> pd.DataFrame:
        """
        Получение данных Google Trends из базы данных
        
        Args:
            category: Категория данных (опционально)
            start_date: Начальная дата (опционально)
            end_date: Конечная дата (опционально)
            
        Returns:
            DataFrame с данными трендов
        """
        try:
            query = "SELECT * FROM google_trends WHERE 1=1"
            params = []
            
            if category:
                query += " AND category = ?"
                params.append(category)
                
            if start_date:
                query += " AND timestamp >= ?"
                params.append(start_date)
                
            if end_date:
                query += " AND timestamp <= ?"
                params.append(end_date)
                
            df = pd.read_sql_query(query, self.db.conn, params=params)
            return df
            
        except Exception as e:
            raise Exception(f"Error getting trends data: {str(e)}")

    def get_correlations(self, start_date, end_date):
        """Получение корреляций за указанный период"""
        try:
            return self.db.get_correlations(start_date, end_date)
        except Exception as e:
            logger.error(f"Error getting correlations: {str(e)}")
            raise

    def get_latest_timestamp(self, table_name):
        """Получение последней временной метки из указанной таблицы"""
        try:
            return self.db.get_latest_timestamp(table_name)
        except Exception as e:
            logger.error(f"Error getting latest timestamp: {str(e)}")
            return None

    def execute_query(self, query: str, params: tuple = None) -> None:
        """
        Выполнение SQL запроса
        
        Args:
            query: SQL запрос
            params: Параметры запроса (опционально)
        """
        try:
            self.db.execute_query(query, params)
        except Exception as e:
            raise Exception(f"Error executing query: {str(e)}")

    def get_trends_data(self, category: str = None, start_date: datetime = None, 
                       end_date: datetime = None) -> pd.DataFrame:
        """
        Получение данных Google Trends из базы данных
        
        Args:
            category: Категория данных (опционально)
            start_date: Начальная дата (опционально)
            end_date: Конечная дата (опционально)
            
        Returns:
            DataFrame с данными трендов
        """
        try:
            query = "SELECT * FROM google_trends WHERE 1=1"
            params = []
            
            if category:
                query += " AND category = ?"
                params.append(category)
                
            if start_date:
                query += " AND timestamp >= ?"
                params.append(start_date)
                
            if end_date:
                query += " AND timestamp <= ?"
                params.append(end_date)
                
            return pd.read_sql_query(query, self.db.conn, params=params)
            
        except Exception as e:
            raise Exception(f"Error getting trends data: {str(e)}")

    def get_latest_trends_dates(self) -> dict:
        """
        Получение последних дат для каждой категории Google Trends
        
        Returns:
            Словарь с последними датами по категориям
        """
        try:
            query = """
                SELECT category, MAX(timestamp) as last_date
                FROM google_trends
                GROUP BY category
            """
            
            df = pd.read_sql_query(query, self.db.conn)
            return dict(zip(df['category'], pd.to_datetime(df['last_date'])))
            
        except Exception as e:
            raise Exception(f"Error getting latest trends dates: {str(e)}")
