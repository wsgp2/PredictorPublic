import requests
import pandas as pd
import logging
from datetime import datetime, timedelta
import os
from pycoingecko import CoinGeckoAPI
from yahoo_finance_collector import YahooFinanceCollector
from blockchain_data_collector_v2 import BlockchainDataCollector
from sentiment_data_collector import SentimentDataCollector
from lunarcrush_collector import LunarCrushCollector
from fred_data_collector import FREDDataCollector
from coinark_collector import CoinArkCollector
from collectors.google_trends_collector import GoogleTrendsCollector
from db import DB  # Импортируем класс DB

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class HistoricalDataCollector:
    def __init__(self):
        """Инициализация коллектора исторических данных"""
        self.data_dir = 'data/historical'
        if not os.path.exists(self.data_dir):
            os.makedirs(self.data_dir)
        
        # API ключи
        self.fred_api_key = 'bb08bba3969b795cb832f4c1eb721494'
        
        # Инициализация коллекторов
        self.cg = CoinGeckoAPI()
        self.blockchain_collector = BlockchainDataCollector()
        self.yahoo_collector = YahooFinanceCollector()
        self.sentiment_collector = SentimentDataCollector()
        self.lunarcrush_collector = LunarCrushCollector()
        self.fred_collector = FREDDataCollector(api_key=self.fred_api_key)
        self.coinark_collector = CoinArkCollector()
        self.google_trends_collector = GoogleTrendsCollector()
        self.db = DB()  # Инициализируем класс DB

    def save_data(self, df, filename):
        """Сохранение DataFrame в CSV файл"""
        try:
            full_path = os.path.join(self.data_dir, filename)
            df.to_csv(full_path, index=False)
            logger.info(f"Data saved to {full_path}")
        except Exception as e:
            logger.error(f"Error saving data to {filename}: {str(e)}")

    def load_historical_data(self, filename):
        """Загрузка исторических данных из CSV файла"""
        try:
            full_path = os.path.join(self.data_dir, filename)
            if os.path.exists(full_path):
                df = pd.read_csv(full_path)
                df['timestamp'] = pd.to_datetime(df['timestamp'])
                return df
            return None
        except Exception as e:
            logger.error(f"Error loading historical data from {filename}: {str(e)}")
            return None

    def get_latest_timestamp(self, df):
        """Получение последней временной метки из DataFrame"""
        if df is not None and not df.empty:
            return df['timestamp'].max()
        return None

    def merge_and_save_data(self, historical_df, new_df, filename):
        """Объединение исторических и новых данных и сохранение результата"""
        try:
            if historical_df is None:
                merged_df = new_df
            else:
                # Объединяем старые и новые данные
                merged_df = pd.concat([historical_df, new_df])
                # Удаляем дубликаты
                merged_df = merged_df.drop_duplicates(subset=['timestamp'])
                # Сортируем по времени
                merged_df = merged_df.sort_values('timestamp')
            
            self.save_data(merged_df, filename)
            return merged_df
        except Exception as e:
            logger.error(f"Error merging data: {str(e)}")
            return None

    def update_historical_data(self, data_getter, filename, metric_name, **kwargs):
        """Обновление исторических данных"""
        try:
            # Загружаем исторические данные
            historical_df = self.load_historical_data(filename)
            latest_timestamp = None
            
            if historical_df is not None and not historical_df.empty:
                latest_timestamp = self.get_latest_timestamp(historical_df)
                logger.info(f"Latest timestamp for {metric_name}: {latest_timestamp}")
            
            # Получаем новые данные
            new_df = data_getter(**kwargs)
            
            if new_df is not None and not new_df.empty:
                # Если есть исторические данные, фильтруем только новые записи
                if latest_timestamp:
                    new_df = new_df[new_df['timestamp'] > latest_timestamp]
                
                if not new_df.empty:
                    # Сохраняем в базу данных
                    if 'market_' in filename:
                        self.db.insert_market_data(new_df)
                    elif 'mining_' in filename:
                        self.db.insert_on_chain_metrics(new_df)
                    elif 'network_' in filename:
                        self.db.insert_on_chain_metrics(new_df)
                    elif 'blockchain_' in filename:
                        self.db.insert_on_chain_metrics(new_df)
                    
                    # Объединяем и сохраняем данные в CSV
                    merged_df = self.merge_and_save_data(historical_df, new_df, filename)
                    return merged_df
                else:
                    logger.info(f"No new data for {metric_name}")
                    return historical_df
            else:
                logger.error(f"Failed to get new data for {metric_name}")
                return historical_df
                
        except Exception as e:
            logger.error(f"Error updating {metric_name}: {str(e)}")
            return None

    def update_all_data(self):
        """Обновление всех исторических данных"""
        # Blockchain.com рыночные данные
        market_metrics = {
            'price': 'market-price',  # Цена в USD
            'market_cap': 'market-cap',  # Рыночная капитализация
            'volume': 'trade-volume',  # Объем торгов
            'volume_usd': 'volume-usd',  # Объем в USD
        }
        
        for metric, endpoint in market_metrics.items():
            df = self.update_historical_data(
                lambda **kwargs: self.get_blockchain_metric(endpoint, **kwargs),
                f'market_{metric}.csv',
                metric,
                timespan='all',
                rolling_average='24hours'
            )
            if df is not None:
                logger.info(f"{metric} records: {len(df)}")
        
        # Blockchain.com майнинг метрики
        mining_metrics = {
            'miners_revenue': 'miners-revenue',  # Доход майнеров
            'mining_revenue_percentage': 'mining-revenue-percentage',  # % дохода от комиссий
        }
        
        for metric, endpoint in mining_metrics.items():
            df = self.update_historical_data(
                lambda **kwargs: self.get_blockchain_metric(endpoint, **kwargs),
                f'mining_{metric}.csv',
                metric,
                timespan='all',
                rolling_average='24hours'
            )
            if df is not None:
                logger.info(f"{metric} records: {len(df)}")
        
        # Blockchain.com сетевые метрики
        network_metrics = {
            'unique_addresses': 'n-unique-addresses',  # Уникальные адреса
            'total_transactions': 'n-transactions-total',  # Общее число транзакций
            'estimated_volume': 'estimated-transaction-volume',  # Оценочный объем
            'estimated_volume_usd': 'estimated-transaction-volume-usd',  # Оценочный объем в USD
        }
        
        for metric, endpoint in network_metrics.items():
            df = self.update_historical_data(
                lambda **kwargs: self.get_blockchain_metric(endpoint, **kwargs),
                f'network_{metric}.csv',
                metric,
                timespan='all',
                rolling_average='24hours'
            )
            if df is not None:
                logger.info(f"{metric} records: {len(df)}")
        
        # Blockchain.com дополнительные метрики
        blockchain_metrics = {
            'difficulty': 'difficulty',
            'avg_block_size': 'avg-block-size',
            'transaction_fees': 'transaction-fees',
            'median_confirmation_time': 'median-confirmation-time',
            'confirmed_transactions': 'n-transactions-excluding-popular',
            'mempool_size': 'mempool-size',
            'transactions_per_block': 'n-transactions-per-block',
            'cost_per_transaction': 'cost-per-transaction',
            'utxo_count': 'utxo-count',
        }
        
        for metric, endpoint in blockchain_metrics.items():
            df = self.update_historical_data(
                lambda **kwargs: self.get_blockchain_metric(endpoint, **kwargs),
                f'blockchain_{metric}.csv',
                metric,
                timespan='all',
                rolling_average='24hours'
            )
            if df is not None:
                logger.info(f"{metric} records: {len(df)}")
        
        # Обновляем данные о деривативах и фьючерсах
        logger.info("Updating derivatives and futures data from CoinArk...")
        try:
            # Получаем последние временные метки
            latest_longshort = self.db.get_latest_timestamp('longshort_data')
            latest_market = self.db.get_latest_timestamp('market_data')
            
            current_time = pd.Timestamp.now()
            update_interval = pd.Timedelta(seconds=self.config['DATA_COLLECTION']['update_interval'])

            # Проверяем, нужно ли обновлять данные
            if latest_longshort and (current_time - latest_longshort) < update_interval:
                logger.info(f"Long/Short data is up to date. Last update: {latest_longshort}")
                need_longshort_update = False
            else:
                need_longshort_update = True
                
            if latest_market and (current_time - latest_market) < update_interval:
                logger.info(f"Market data is up to date. Last update: {latest_market}")
                need_market_update = False
            else:
                need_market_update = True

            if not need_longshort_update and not need_market_update:
                logger.info("All derivatives data is up to date")
                return

            # 1. Данные о ставках финансирования
            if need_longshort_update:
                for period in ['current', 'day', 'week', 'month']:
                    funding_rate = self.coinark_collector.get_funding_rate(type=period)
                    if funding_rate is not None and not funding_rate.empty:
                        # Фильтруем только новые данные
                        if latest_longshort:
                            funding_rate = funding_rate[funding_rate['timestamp'] > latest_longshort]
                        
                        if not funding_rate.empty:
                            funding_df = pd.DataFrame({
                                'timestamp': funding_rate['timestamp'],
                                'symbol': funding_rate['symbol'],
                                'timeframe': period,
                                'long_position_ratio': funding_rate['longRate'],
                                'short_position_ratio': funding_rate['shortRate']
                            })
                            self.db.insert_longshort_data(funding_df)
                            logger.info(f"Updated funding rate data for period: {period}")
                        else:
                            logger.info(f"No new funding rate data for period: {period}")

            # 2. Данные об открытом интересе и ликвидациях
            if need_market_update:
                for coin in ['BTC', 'ETH']:
                    for interval in ['1h', '4h', '1d']:
                        # Открытый интерес
                        oi_data = self.coinark_collector.get_open_interest(
                            base_coin=coin,
                            interval=interval
                        )
                        if oi_data is not None and not oi_data.empty:
                            # Фильтруем только новые данные
                            if latest_market:
                                oi_data = oi_data[oi_data['timestamp'] > latest_market]
                            
                            if not oi_data.empty:
                                market_df = pd.DataFrame({
                                    'timestamp': oi_data['timestamp'],
                                    'volume': oi_data['volume'],
                                    'market_cap': oi_data['openInterest']
                                })
                                self.db.insert_market_data(market_df)
                                logger.info(f"Updated open interest data for {coin} {interval}")
                            else:
                                logger.info(f"No new open interest data for {coin} {interval}")

                        # Ликвидации
                        liq_data = self.coinark_collector.get_liquidations(
                            base_coin=coin,
                            interval=interval
                        )
                        if liq_data is not None and not liq_data.empty:
                            # Фильтруем только новые данные
                            if latest_market:
                                liq_data = liq_data[liq_data['timestamp'] > latest_market]
                            
                            if not liq_data.empty:
                                market_df = pd.DataFrame({
                                    'timestamp': liq_data['timestamp'],
                                    'liquidations': liq_data['value']
                                })
                                self.db.insert_market_data(market_df)
                                logger.info(f"Updated liquidation data for {coin} {interval}")
                            else:
                                logger.info(f"No new liquidation data for {coin} {interval}")

            # 3. Данные о соотношении длинных/коротких позиций
            if need_longshort_update:
                for symbol in ['BTCUSDT', 'ETHUSDT']:
                    for ls_type in ['longShortPerson', 'longShortPosition', 'longShortAccount']:
                        for interval in ['1h', '4h', '1d']:
                            ls_data = self.coinark_collector.get_longshort_kline(
                                symbol=symbol,
                                interval=interval,
                                ls_type=ls_type
                            )
                            if ls_data is not None and not ls_data.empty:
                                # Фильтруем только новые данные
                                if latest_longshort:
                                    ls_data = ls_data[ls_data['timestamp'] > latest_longshort]
                                
                                if not ls_data.empty:
                                    ratio_df = pd.DataFrame({
                                        'timestamp': ls_data['timestamp'],
                                        'symbol': symbol,
                                        'timeframe': interval
                                    })
                                    
                                    if ls_type == 'longShortPerson':
                                        ratio_df['long_person_ratio'] = ls_data['ratio_close']
                                        ratio_df['short_person_ratio'] = 1 - ls_data['ratio_close']
                                    elif ls_type == 'longShortPosition':
                                        ratio_df['long_position_ratio'] = ls_data['ratio_close']
                                        ratio_df['short_position_ratio'] = 1 - ls_data['ratio_close']
                                    else:  # longShortAccount
                                        ratio_df['long_account_ratio'] = ls_data['ratio_close']
                                        ratio_df['short_account_ratio'] = 1 - ls_data['ratio_close']
                                    
                                    self.db.insert_longshort_data(ratio_df)
                                    logger.info(f"Updated long/short data for {symbol} {ls_type} {interval}")
                                else:
                                    logger.info(f"No new long/short data for {symbol} {ls_type} {interval}")

            # 4. Данные индикаторов
            if need_market_update:
                indicators = [
                    'bitcoin-rainbow-v2',
                    '/charts/1-year-hodl-wave/',
                    '/charts/hodl-waves/',
                    '/charts/mvrv-zscore/',
                    '/charts/relative-unrealized-prof/',
                    '/charts/bitcoin-price-prediction/',
                    '/charts/reserve-risk/',
                    '/charts/rhodl-ratio/',
                    '/charts/whale-shadows/'
                ]
                for indicator in indicators:
                    ind_data = self.coinark_collector.get_indicator_data(indicator)
                    if ind_data is not None and not ind_data.empty:
                        # Фильтруем только новые данные
                        if latest_market:
                            ind_data = ind_data[ind_data['timestamp'] > latest_market]
                        
                        if not ind_data.empty:
                            indicator_name = indicator.replace('/', '').replace('-', '_')
                            market_df = pd.DataFrame({
                                'timestamp': ind_data['timestamp'],
                                indicator_name: ind_data['value']
                            })
                            self.db.insert_market_data(market_df)
                            logger.info(f"Updated indicator data for {indicator}")
                        else:
                            logger.info(f"No new indicator data for {indicator}")

            # 5. Данные ордербука
            if need_market_update:
                for symbol in ['BTCUSDT', 'ETHUSDT']:
                    for rate in ['0.01', '0.03', '0.05']:
                        for interval in ['1h', '4h', '1d']:
                            ob_data = self.coinark_collector.get_orderbook_by_symbol(
                                symbol=symbol,
                                rate=rate,
                                interval=interval
                            )
                            if ob_data is not None and not ob_data.empty:
                                # Фильтруем только новые данные
                                if latest_market:
                                    ob_data = ob_data[ob_data['timestamp'] > latest_market]
                                
                                if not ob_data.empty:
                                    market_df = pd.DataFrame({
                                        'timestamp': ob_data['timestamp'],
                                        f'orderbook_imbalance_{rate}': ob_data['value']
                                    })
                                    self.db.insert_market_data(market_df)
                                    logger.info(f"Updated orderbook data for {symbol} rate {rate} {interval}")
                                else:
                                    logger.info(f"No new orderbook data for {symbol} rate {rate} {interval}")

        except Exception as e:
            logger.error(f"Error updating derivatives data: {str(e)}")

    def collect_google_trends_data(self):
        """Сбор данных из Google Trends"""
        try:
            logger.info("Начинаем сбор данных из Google Trends")
            self.google_trends_collector.run_collection()
            logger.info("Сбор данных из Google Trends завершен")
        except Exception as e:
            logger.error(f"Ошибка при сборе данных из Google Trends: {str(e)}")

    def collect_all_data(self, force_update: bool = False):
        """
        Сбор всех исторических данных
        
        Args:
            force_update: Принудительное обновление всех данных
        """
        try:
            # 1. Сбор данных из Google Trends
            self.collect_google_trends_data()
            
            # 2. Сбор данных с Yahoo Finance
            logger.info("Collecting Yahoo Finance data...")
            yahoo_data = self.yahoo_collector.get_all_data()
            if yahoo_data is not None:
                for symbol, data in yahoo_data.items():
                    if not data.empty:
                        self.db.insert_related_assets(data)
                        filename = f'yahoo_{symbol.lower()}.csv'
                        self.save_data(data, filename)
                        logger.info(f"Saved Yahoo Finance data for {symbol}")
            
            # 3. Сбор данных о настроениях
            logger.info("Collecting sentiment data...")
            sentiment_data = self.sentiment_collector.get_sentiment_data()
            if sentiment_data is not None and not sentiment_data.empty:
                self.db.insert_sentiment_metrics(sentiment_data)
                self.save_data(sentiment_data, 'sentiment_data.csv')
                logger.info("Saved sentiment data")
            
            # 4. Сбор данных LunarCrush
            logger.info("Collecting LunarCrush data...")
            lunarcrush_data = self.lunarcrush_collector.get_all_metrics()
            if lunarcrush_data is not None and not lunarcrush_data.empty:
                self.db.insert_sentiment_metrics(lunarcrush_data)
                self.save_data(lunarcrush_data, 'lunarcrush_data.csv')
                logger.info("Saved LunarCrush data")
            
            # 5. Сбор данных FRED
            logger.info("Collecting FRED data...")
            fred_data = self.fred_collector.get_all_series()
            if fred_data is not None and not fred_data.empty:
                self.db.insert_market_data(fred_data)
                self.save_data(fred_data, 'fred_data.csv')
                logger.info("Saved FRED data")
            
            # 6. Обновление всех исторических данных
            self.update_all_data()
            
            logger.info("All data collection completed successfully")
            
        except Exception as e:
            logger.error(f"Error collecting all data: {str(e)}")

    def get_blockchain_metric(self, endpoint, timespan='all', rolling_average='24hours'):
        """Получение метрики с blockchain.info через BlockchainDataCollector"""
        return self.blockchain_collector.get_blockchain_metric(endpoint, timespan, rolling_average)

def main():
    """Основная функция для сбора данных"""
    try:
        collector = HistoricalDataCollector()
        
        # Собираем все данные из разных источников
        collector.collect_all_data()
        
        # Проверяем корреляции между метриками
        logger.info("Анализ корреляций между метриками...")
        
        # Получаем все метрики из Blockchain.info
        blockchain_metrics = [
            'trade_volume', 'miners_revenue', 'estimated_transaction_volume_usd',
            'market_price', 'total_bitcoins', 'market_cap', 'hash_rate',
            'difficulty', 'transaction_fees', 'n_unique_addresses', 'n_transactions'
        ]
        
        # Создаем DataFrame для анализа корреляций
        dfs = []
        for metric in blockchain_metrics:
            query = f"""
                SELECT timestamp, value as {metric}
                FROM blockchain_{metric}
                ORDER BY timestamp
            """
            df = pd.read_sql_query(query, collector.blockchain_collector.conn)
            dfs.append(df.set_index('timestamp'))
        
        # Объединяем все метрики
        combined_df = pd.concat(dfs, axis=1)
        
        # Рассчитываем корреляции
        correlations = combined_df.corr()
        
        # Сохраняем корреляции в CSV
        correlations.to_csv('data/historical/blockchain_correlations.csv')
        logger.info("Корреляции сохранены в blockchain_correlations.csv")
        
        # Выводим топ-5 самых сильных корреляций с ценой
        price_correlations = correlations['market_price'].sort_values(ascending=False)
        logger.info("\nТоп-5 метрик с самой сильной корреляцией с ценой:")
        logger.info(price_correlations.head())
        
    except Exception as e:
        logger.error(f"Ошибка в main(): {str(e)}")
    finally:
        if 'collector' in locals():
            collector.blockchain_collector.close()

if __name__ == "__main__":
    main()
